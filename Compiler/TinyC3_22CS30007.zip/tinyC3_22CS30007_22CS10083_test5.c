int v = 9;
int main () {
    float c;
    int d = 9;
    c = (float)d;
    c<=9;
}