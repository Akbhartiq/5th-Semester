int c;
int main (int a, float b, char d) {
    c = a = 8;
    for (c; a; c<9) {
        c=c++ + a++;
    }
}